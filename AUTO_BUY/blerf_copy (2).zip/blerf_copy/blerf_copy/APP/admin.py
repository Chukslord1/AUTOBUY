from django.contrib import admin
from .models import UserProfile,Biography,Blog,NewsLetter,Reply
# Register your models here.
admin.site.register(UserProfile)
admin.site.register(Biography)
admin.site.register(Blog)
admin.site.register(NewsLetter)
admin.site.register(Reply)

