from django.db import models
from django.contrib.auth.models import User
from django.shortcuts import reverse
# Create your models here.
class UserProfile(models.Model):
    user = models.OneToOneField(User, related_name="profile", on_delete=models.CASCADE)
    username=models.CharField(max_length=100, null=True,blank=True)
    name= models.CharField(max_length=100)
    email=models.CharField(max_length=100)

    def __str__(self):
        return self.user.username

class Blog(models.Model):
    title=models.TextField()
    image=models.ImageField(blank=True, null=True)
    summary= models.TextField()
    body=models.TextField()
    date=models.TextField()
    cat=models.TextField()
    slug = models.SlugField()
    creator = models.ForeignKey(User, null=True,blank=True, on_delete=models.CASCADE)
    comment= models.IntegerField()
    paginate_by = 2
    def get_absolute_url(self):
        return reverse("APP:single_post", kwargs={
            'slug': self.slug
        })
    def __str__(self):
        return self.title

class Biography(models.Model):
    title=models.TextField(null=True,blank=True)
    name=models.TextField(null=True,blank=True)
    image=models.ImageField(null=True,blank=True)
    gender=models.TextField(null=True,blank=True)
    email=models.TextField(null=True,blank=True)
    date_of_birth=models.TextField(null=True,blank=True)
    place_of_birth=models.TextField(null=True,blank=True)
    parents=models.TextField(null=True,blank=True)
    parent_status=models.TextField(null=True,blank=True)
    marital_status=models.TextField(null=True,blank=True)
    date_married=models.TextField(null=True,blank=True)
    name_of_spouse=models.TextField(null=True,blank=True)
    name_of_children=models.TextField(null=True,blank=True)
    male_child=models.TextField(null=True,blank=True)
    female_child=models.TextField(null=True,blank=True)
    working_experience=models.TextField(null=True,blank=True)
    profession=models.TextField()
    phone=models.TextField(null=True,blank=True)
    mobile=models.TextField(null=True,blank=True)
    address=models.TextField(null=True,blank=True)
    primary_education=models.TextField(null=True,blank=True)
    secondary_education=models.TextField(null=True,blank=True)
    tetiary_education=models.TextField(null=True,blank=True)
    education_qualification_and_date=models.TextField(null=True,blank=True)
    academic_honours=models.TextField(null=True,blank=True)
    memberships=models.TextField(null=True,blank=True)
    present_appointment=models.TextField(null=True,blank=True)
    previous_appointment=models.TextField(null=True,blank=True)
    political_member_choice=models.TextField(null=True,blank=True)
    political_party=models.TextField(null=True,blank=True)
    int_membership=models.TextField(null=True,blank=True)
    traditional_ties=models.TextField(null=True,blank=True)
    national_honours=models.TextField(null=True,blank=True)
    international_decors=models.TextField(null=True,blank=True)
    honorary_degrees_and_institution=models.TextField()
    achievment=models.TextField(null=True,blank=True)
    motiv_lit=models.TextField(null=True,blank=True)
    role_model=models.TextField(null=True,blank=True)
    quotes=models.TextField(null=True,blank=True)
    hobbies=models.TextField(null=True,blank=True)
    social_club=models.TextField(null=True,blank=True)
    others=models.TextField(null=True,blank=True)
    paginate_by = 2
    slug = models.SlugField()
    def get_absolute_url(self):
        return reverse("APP:single", kwargs={
            'slug': self.slug
        })
    def __str__(self):
        return self.name

class NewsLetter(models.Model):
    email=models.TextField()
    def __str__(self):
        return self.email


class Reply(models.Model):
    blog=models.TextField()
    user=models.ForeignKey(User, null=True,blank=True, on_delete=models.CASCADE)
    reply=models.TextField()
    paginate_by = 2
