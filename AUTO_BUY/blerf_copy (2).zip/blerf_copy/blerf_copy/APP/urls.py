import os
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include
from django.conf.urls.static import static
from . import views
app_name = "APP"
urlpatterns = [
    path("", views.IndexListView.as_view(), name="index"),
    path("index.html", views.IndexListView.as_view(), name="index"),
    path("about-us.html", views.about, name="about"),
    path("about-nyaknno-osso.html", views.about_prof, name="about_prof"),
    path("contact.html", views.contact, name="contact"),
    path("single-post.html/<slug>", views.BlogDetailView.as_view(), name="single_post"),
    path("single.html/<slug>", views.BioDetailView.as_view(), name="single"),
    path("blog.html", views.BlogListView.as_view(), name="blog"),
    path("biographies.html", views.BioListView.as_view(), name="bio"),
    path("signup", views.signup, name="signup"),
    path("login.html", views.login, name="login"),
    path("questionaire.html", views.add_bio, name="add_bio"),
    path("search-complete.html", views.search_complete, name="search_complete"),
    path("comment.html", views.comment, name="comment"),





]
