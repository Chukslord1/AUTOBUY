from django.shortcuts import render,redirect
from django.contrib.auth.models import User, auth
from .models import UserProfile,Biography,Blog,NewsLetter,Reply
from django.views.generic import ListView, DetailView, View
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from django.db.models import Q
from django.core.paginator import Paginator
# Create your views here.
class IndexListView(ListView):
    model = Biography
    template_name = "index.html"
    queryset= Biography.objects.all()
    def get_context_data(self, **kwargs):
        context = super(IndexListView, self).get_context_data(**kwargs)
        if self.request.GET.get('sub')=="true":
            email=self.request.GET.get('email')
            check_email=NewsLetter.objects.filter(email=email)
            if check_email.exists():
                context['message']=' This Email is Subscribed Already'
            else:
                news=NewsLetter.objects.create(email=email)
                news.save()
                context['message']='Subscribed Successfully'
                fromaddr = "e-lib-send@advancescholar.com"
                toaddr = email
                subject="Newsletter Subscription"
                msg = MIMEMultipart()
                msg['From'] = fromaddr
                msg['To'] = toaddr
                msg['Subject'] = subject


                body = "You have successfully subscribed to our Newsletter..Look Up our website @ www.blerf.advancescholar.com and start Using our books "
                msg.attach(MIMEText(body, 'plain'))

                server = smtplib.SMTP('mail.advancescholar.com',  26)
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login("e-lib-send@advancescholar.com", "e-library@24hubs")
                text = msg.as_string()
                server.sendmail(fromaddr, toaddr, text)

        context['bios'] = Biography.objects.all()[:6]
        context['blog'] = Blog.objects.all()[0:3]
        context['blogs'] = Blog.objects.all()[0:4]
        context['chemical'] = Biography.objects.filter(Q(profession__icontains="Chemical Engineer"))
        context['computer'] = Biography.objects.filter(Q(profession__icontains="Computer"))
        context['tech'] = Biography.objects.filter(Q(profession__icontains="Tech"))
        context['art'] = Biography.objects.filter(Q(profession__icontains="Art"))
        context['health'] = Biography.objects.filter(Q(profession__icontains="health"))
        return context


def about(request):
    return render(request,"about-university.html")

def about_prof(request):
    return render(request,"about-nyaknno-osso.html")

def contact(request):
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        message=request.POST['message']
        fromaddr = "e-lib-send@advancescholar.com"
        toaddr = "e-library@advancescholar.com"
        subject=email + " needs assistance"
        msg = MIMEMultipart()
        msg['From'] = fromaddr
        msg['To'] = toaddr
        msg['Subject'] = subject


        body = message
        msg.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP('mail.advancescholar.com',  26)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("e-lib-send@advancescholar.com", "e-library@24hubs")
        text = msg.as_string()
        server.sendmail(fromaddr, toaddr, text)
        context={'message':'Your message has been sent sucessfully'}
        return render(request, 'contact-us.html',context)
    return render(request, 'contact-us.html')


class BlogDetailView(DetailView):
    model= Blog
    template_name="single-post.html"
    def get_context_data(self, **kwargs):
        context = super(BlogDetailView, self).get_context_data(**kwargs)
        if self.request.GET.get("reply")=="true":
            comment=self.request.GET.get("comment")
            slug=self.request.GET.get("blog")
            reply=Reply.objects.create(blog=slug,user=self.request.user,reply=comment)
            reply.save()
            blog=Blog.objects.get(title=slug)
            number=Blog.objects.get(title=slug).comment
            total=number+1
            blog.comment=total
            blog.save()
        else:
            pass

        return context

class BioDetailView(DetailView):
    model=Biography
    template_name="single.html"
    def get_context_data(self, **kwargs):
        context = super(BioDetailView, self).get_context_data(**kwargs)

        return context

class BlogListView(ListView):
    model=Blog
    template_name="blog.html"
    def get_context_data(self, **kwargs):
        context = super(BlogListView, self).get_context_data(**kwargs)
        if self.request.GET.get('sub')=="true":
            email=self.request.GET.get('email')
            check_email=NewsLetter.objects.filter(email=email)
            if check_email.exists():
                context['message']=' This Email is Subscribed Already'
            else:
                news=NewsLetter.objects.create(email=email)
                news.save()
                context['message']='Subscribed Successfully'
                fromaddr = "e-lib-send@advancescholar.com"
                toaddr = email
                subject="Newsletter Subscription"
                msg = MIMEMultipart()
                msg['From'] = fromaddr
                msg['To'] = toaddr
                msg['Subject'] = subject


                body = "You have successfully subscribed to our Newsletter..Look Up our website @ www.blerf.advancescholar.com and start Using our books "
                msg.attach(MIMEText(body, 'plain'))

                server = smtplib.SMTP('mail.advancescholar.com',  26)
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login("e-lib-send@advancescholar.com", "e-library@24hubs")
                text = msg.as_string()
                server.sendmail(fromaddr, toaddr, text)
        paginator= Paginator(Blog.objects.all(),10)
        page_number = self.request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        context['page_obj'] = page_obj
        return context



class BioListView(ListView):
    model=Biography
    template_name="bio.html"
    def get_context_data(self, **kwargs):
        context = super(BioListView, self).get_context_data(**kwargs)
        if self.request.GET.get('sub')=="true":
            email=self.request.GET.get('email')
            check_email=NewsLetter.objects.filter(email=email)
            if check_email.exists():
                context['message']=' This Email is Subscribed Already'
            else:
                news=NewsLetter.objects.create(email=email)
                news.save()
                context['message']='Subscribed Successfully'
                fromaddr = "e-lib-send@advancescholar.com"
                toaddr = email
                subject="Newsletter Subscription"
                msg = MIMEMultipart()
                msg['From'] = fromaddr
                msg['To'] = toaddr
                msg['Subject'] = subject


                body = "You have successfully subscribed to our Newsletter..Look Up our website @ www.blerf.advancescholar.com and start Using our books "
                msg.attach(MIMEText(body, 'plain'))

                server = smtplib.SMTP('mail.advancescholar.com',  26)
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login("e-lib-send@advancescholar.com", "e-library@24hubs")
                text = msg.as_string()
                server.sendmail(fromaddr, toaddr, text)

        context["cat"]=Blog.objects.all().values_list('cat')
        context = super(BioListView, self).get_context_data(**kwargs)
        paginator= Paginator(Biography.objects.all(),10)
        page_number = self.request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        context['page_obj'] = page_obj
        return context

def signup(request):
    if request.method=="POST":
        name=request.POST.get("name")
        email=request.POST.get("email")
        username=request.POST.get("username")
        password1=request.POST.get("password1")
        password2=request.POST.get("password2")
        if password1 == password2:
                if User.objects.filter(email=email).exists():

                    return render(request, 'signup.html')
                else:
                    user = User.objects.create(
                        username=username, password=password1, email=email)
                    user.set_password(user.password)
                    user.save()
                    profile=UserProfile.objects.create(user=user,
                        username=username, name=name, email=email)
                    profile.save()
                    return redirect(request,'login.html')
        else:
            context={"message":"incorrect details"}
            return render(request,'signup.html',context)
    return render(request,"signup.html")

def login(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect("index.html")
        else:
            return render(request, 'login.html', {"message": "The user does not exist"})
    else:
        return render(request,'login.html')

def add_bio(request):
    if request.method=="POST":
        title=request.POST.get("title")
        name=request.POST.get("name")
        image=request.FILES.get("image")
        gender=request.POST.get("gender")
        email=request.POST.get("email")
        date_of_birth=request.POST.get("dob")
        place_of_birth=request.POST.get("pob")
        parents=request.POST.get("parents")
        working_experience=request.POST.get("working_experience")
        parents_status=request.POST.get("parents_status")
        marital_status=request.POST.get("marital_status")
        date_married=request.POST.get("date_married")
        name_spouse=request.POST.get("name_spouse")
        name_children=request.POST.get("name_children")
        female_child=request.POST.get("female_child")
        male_child=request.POST.get("male_child")
        profession=request.POST.get("profession")
        phone=request.POST.get("phone")
        mobile=request.POST.get("mobile")
        address=request.POST.get("address")
        primary_edu=request.POST.get("primary_edu")
        secondary_edu=request.POST.get("secondary_edu")
        tetiary_edu=request.POST.get("tetiary_edu")
        edu_and_date=request.POST.get("edu_and_date")
        academic_honours=request.POST.get("academic_honours")
        memberships=request.POST.get("memberships")
        present_appoint=request.POST.get("present_appoint")
        previous_appoint=request.POST.get("previous_appoint")
        politcal_choice=request.POST.get("political_choice")
        party=request.POST.get("party")
        int_membership=request.POST.get("int_membership")
        trad_ties=request.POST.get("trad_ties")
        int_decors=request.POST.get("int_decors")
        hon_and_institution=request.POST.get("hon_and_institution")
        achievment=request.POST.get("achievment")
        motiv_lit=request.POST.get("motiv_lit")
        role_model=request.POST.get("role_model")
        quotes=request.POST.get("quotes")
        hobbies=request.POST.get("hobbies")
        social_club=request.POST.get("social_club")
        others=request.POST.get("others")
        nat_honours=request.POST.get("nat_honours")

        if Biography.objects.filter(name=name,date_of_birth=date_of_birth).exists():
            return render(request,"add-bio.html",{"message":"Biography Already Exists"})
        else:
            bio=Biography.objects.create(title=title,name=name,gender=gender,image=image,email=email,date_of_birth=date_of_birth,place_of_birth=place_of_birth,parents=parents,parent_status=parents_status,marital_status=marital_status,date_married=date_married,name_of_spouse=name_spouse,name_of_children=name_children,male_child=male_child,female_child=female_child,profession=profession,phone=phone,mobile=mobile,address=address,primary_education=primary_edu,secondary_education=secondary_edu,tetiary_education=tetiary_edu,education_qualification_and_date=edu_and_date,academic_honours=academic_honours,memberships=memberships,present_appointment=present_appoint,previous_appointment=previous_appoint,political_party=party,int_membership=int_membership,traditional_ties=trad_ties,national_honours=nat_honours,international_decors=int_decors,honorary_degrees_and_institution=hon_and_institution,achievment=achievment,motiv_lit=motiv_lit,role_model=role_model,quotes=quotes,hobbies=hobbies,social_club=social_club,others=others,working_experience=working_experience)
            bio.save()
    return render(request,"add-bio.html")


def search_complete(request):
    if request.GET.get("tenth_check")=="ten":
        query=request.GET.get("search")
        if query:
            search = Biography.objects.filter(Q(name__icontains=query))
            find=Blog.objects.filter(Q(title__icontains=query))
            context={"search":search,"find":find,"query":query}
            return render(request,"search-complete.html",context)
        else:
            search = Biography.objects.none()
            find=Blog.objects.none()
            context={"search":search,"find":find}
            return render(request,"search-complete.html",context)
    return render(request,"search-complete.html")

def comment(request):
    if request.GET.get("comment")=="true":
        title=request.GET.get("title")
        if title:
            paginator= Paginator(Reply.objects.filter(blog=title),10)
            page_number = request.GET.get('page')
            page_obj = paginator.get_page(page_number)
            context={"page_obj":page_obj}
            return render(request,"comment.html",context)
        else:
            search = Reply.objects.none()
            context={"search":search}
            return render(request,"comment.html",context)
    return render(request,"comment.html")
